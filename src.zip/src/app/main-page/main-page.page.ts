import { Component } from '@angular/core';

@Component({
  selector: 'app-main-page',
  templateUrl: './main-page.page.html',
  styleUrls: ['./main-page.page.scss'],
})
export class MainPagePage  {


  list = [
    { name: 'Home', url: '/main-page/usercomponmentcomp'},
    { name: 'Users', url: '/main-page/form'},
    { name: 'Logout', url: '/home'},

  ];
  
  constructor() { }

  



  drawerVisible = false;

  toggleDrawer(): void {
    this.drawerVisible = !this.drawerVisible;
  }
}
